import React from 'react';
import { useNavigate } from 'react-router-dom';
import { formatDate } from '../../shared/utils/dateUtils';
import { useWorkoutContext } from '../../context/WorkoutContext';

/**
 * WorkoutHistory Component
 * 
 * Displays a list of saved workout plans for a player
 * Features:
 * - View saved workout plans
 * - Load a plan for editing
 * - Delete a plan
 * - Duplicate a plan
 */
const WorkoutHistory = ({ playerId }) => {
  const navigate = useNavigate();
  const { getPlayerWorkoutPlans, loadWorkoutPlan, deleteWorkoutPlan, duplicateWorkoutPlan } = useWorkoutContext();
  
  // Get all workout plans for this player
  const playerWorkouts = getPlayerWorkoutPlans(playerId);
  
  // Sort workouts by creation date (newest first)
  const sortedWorkouts = [...playerWorkouts].sort((a, b) => 
    new Date(b.createdAt) - new Date(a.createdAt)
  );
  
  // Count blocks and exercises in a workout plan
  const countWorkoutComponents = (workout) => {
    const blockCount = workout.blocks.length;
    const exerciseCount = workout.blocks.reduce(
      (total, block) => total + block.exercises.length, 
      0
    );
    
    return { blockCount, exerciseCount };
  };
  
  // Handle loading a workout for editing
  const handleLoadWorkout = (planId) => {
    loadWorkoutPlan(planId);
    navigate('/workouts');
  };
  
  // Handle deleting a workout
  const handleDeleteWorkout = (planId, planName) => {
    const confirmDelete = window.confirm(`Are you sure you want to delete "${planName}"?`);
    if (confirmDelete) {
      deleteWorkoutPlan(planId);
    }
  };
  
  // Handle duplicating a workout
  const handleDuplicateWorkout = (planId) => {
    duplicateWorkoutPlan(planId);
  };
  
  // If no workouts, show a message
  if (sortedWorkouts.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h3 className="text-lg font-semibold mb-4 text-gray-700 border-b border-gray-200 pb-2">
          Workout History
        </h3>
        <div className="text-center py-8">
          <p className="text-gray-500 mb-4">No saved workout plans found.</p>
          <button
            onClick={() => navigate('/workouts')}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          >
            Create New Workout
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex justify-between items-center mb-4 border-b border-gray-200 pb-2">
        <h3 className="text-lg font-semibold text-gray-700">
          Workout History
        </h3>
        <button
          onClick={() => navigate('/workouts')}
          className="px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700 flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          New Workout
        </button>
      </div>
      
      {/* Workout List */}
      <div className="space-y-4">
        {sortedWorkouts.map((workout) => {
          const { blockCount, exerciseCount } = countWorkoutComponents(workout);
          const createdDate = new Date(workout.createdAt);
          
          return (
            <div key={workout.id} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md">
              <div className="bg-gray-50 px-4 py-3 flex justify-between items-center border-b border-gray-200">
                <h4 className="font-medium text-gray-800">{workout.name}</h4>
                <span className="text-sm text-gray-500">
                  {formatDate(createdDate)}
                </span>
              </div>
              
              <div className="p-4">
                {/* Workout Stats */}
                <div className="flex items-center gap-4 mb-4 text-sm">
                  <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full">
                    {blockCount} {blockCount === 1 ? 'Block' : 'Blocks'}
                  </div>
                  <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full">
                    {exerciseCount} {exerciseCount === 1 ? 'Exercise' : 'Exercises'}
                  </div>
                </div>
                
                {/* Description */}
                {workout.description && (
                  <p className="text-gray-600 text-sm mb-4">
                    {workout.description}
                  </p>
                )}
                
                {/* Action Buttons */}
                <div className="flex justify-end space-x-2">
                  <button
                    onClick={() => handleDuplicateWorkout(workout.id)}
                    className="text-gray-600 hover:text-gray-800 text-sm font-medium"
                  >
                    Duplicate
                  </button>
                  <button
                    onClick={() => handleDeleteWorkout(workout.id, workout.name)}
                    className="text-red-600 hover:text-red-800 text-sm font-medium"
                  >
                    Delete
                  </button>
                  <button
                    onClick={() => handleLoadWorkout(workout.id)}
                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700"
                  >
                    Load
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default WorkoutHistory;